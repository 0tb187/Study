Action()
{
	int i = (rand() % 3) + 1;
	
	lr_start_transaction("UC_05_DeleteTicket");
	
	login();

	lr_start_transaction("itinerary_page");
		
		web_reg_find("Text=User wants",                                                                          //FIND******************
			LAST);
			
		web_reg_save_param("flightIDArr",
			"LB=flightID\" value=\"",
			"RB=\"",
			"Ord=ALL",
			LAST);
			
		web_add_auto_header("Sec-Fetch-User", 
			"?1");
	
		web_add_auto_header("Upgrade-Insecure-Requests", 
			"1");
	
		web_url("Itinerary Button", 
			"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
			"TargetFrame=body", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
			"Snapshot=t3.inf", 
			"Mode=HTML", 
			LAST);
		
	lr_end_transaction("itinerary_page", LR_AUTO);
	
	lr_think_time(5);
	
	lr_start_transaction("delete_ticket");
	
	lr_save_string(lr_eval_string("{flightIDArr_1}"),"flightID1");
	
	web_reg_find("Text/IC={flightID1}", "Search=Body", "Fail=Found",                                        //FIND******************
			LAST);
	
	
		web_add_header("Origin", 
			"http://localhost:1080");
	
		web_submit_form("itinerary.pl", 
			"Snapshot=t4.inf", 
			ITEMDATA, 
			"Name=1", "Value=on", ENDITEM, 
			"Name=removeFlights.x", "Value=44", ENDITEM, 
			"Name=removeFlights.y", "Value=8", ENDITEM,
			LAST);
		
	lr_end_transaction("delete_ticket", LR_AUTO);

	lr_think_time(5);
	
	logout();
	
	lr_end_transaction("UC_05_DeleteTicket", LR_AUTO);
	
	return 0;
}