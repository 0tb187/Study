Action()
{
		
	lr_start_transaction("UC3_BuyTicket");
	
	login();
	
	lr_start_transaction("search_flight");
	
		web_reg_find("Text=User has returned",                                                                          //FIND******************
			LAST);
	
		web_add_auto_header("Sec-Fetch-User", 
			"?1");
	
		web_add_auto_header("Upgrade-Insecure-Requests", 
			"1");
	
		web_url("Search Flights Button", 
			"URL=http://localhost:1080/cgi-bin/welcome.pl?page=search", 
			"TargetFrame=body", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
			"Snapshot=t32.inf", 
			"Mode=HTML", 
			LAST);
	
	lr_end_transaction("search_flight", LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("choose_flight");

		web_reg_find("Text=Find Flight",                                                                          //FIND******************
			LAST);
	
		web_add_auto_header("Origin", 
			"http://localhost:1080");
	
		/*Correlation comment - Do not change!  Original value='011;498;04/08/2023' Name ='outboundFlight' Type ='Manual'*/
		web_reg_save_param_attrib(
			"ParamName=outboundFlight",
			"TagName=input",
			"Extract=value",
			"Name=outboundFlight",
			"Type=radio",
			SEARCH_FILTERS,
			"IgnoreRedirections=No",
			LAST);
	
	/*Correlation comment - Do not change!  Original value='101;498;04/09/2023' Name ='returnFlight' Type ='Manual'*/
		web_reg_save_param_attrib(
			"ParamName=returnFlight",
			"TagName=input",
			"Extract=value",
			"Name=returnFlight",
			"Type=radio",
			SEARCH_FILTERS,
			"IgnoreRedirections=No",
			LAST);
			
		web_submit_data("reservations.pl", 
			"Action=http://localhost:1080/cgi-bin/reservations.pl", 
			"Method=POST", 
			"TargetFrame=", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/cgi-bin/reservations.pl?page=welcome", 
			"Snapshot=t33.inf", 
			"Mode=HTML", 
			ITEMDATA, 
			"Name=advanceDiscount", "Value=0", ENDITEM, 
			"Name=depart", "Value={departCity}", ENDITEM, 
			"Name=departDate", "Value={departDate}", ENDITEM, 
			"Name=arrive", "Value={arriveCity}", ENDITEM, 
			"Name=returnDate", "Value={returnDate}", ENDITEM, 
			"Name=numPassengers", "Value=1", ENDITEM, 
			"Name=roundtrip", "Value=on", ENDITEM, 
			"Name=seatPref", "Value={seatPref}", ENDITEM, 
			"Name=seatType", "Value={seatType}", ENDITEM, 
			"Name=findFlights.x", "Value=43", ENDITEM, 
			"Name=findFlights.y", "Value=7", ENDITEM, 
			"Name=.cgifields", "Value=roundtrip", ENDITEM, 
			"Name=.cgifields", "Value=seatType", ENDITEM, 
			"Name=.cgifields", "Value=seatPref", ENDITEM, 
			LAST);
	
	lr_end_transaction("choose_flight", LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("choose_ticket");
	
		web_reg_find("Text=First Name :",                                                                          //FIND******************
			LAST);
		
		
		web_submit_data("reservations.pl_2",
			"Action=http://localhost:1080/cgi-bin/reservations.pl",
			"Method=POST",
			"TargetFrame=",
			"RecContentType=text/html",
			"Referer=http://localhost:1080/cgi-bin/reservations.pl",
			"Snapshot=t34.inf",
			"Mode=HTML",
			ITEMDATA,
			"Name=outboundFlight", "Value={outboundFlight}", ENDITEM,
			"Name=returnFlight", "Value={returnFlight}", ENDITEM,
			"Name=numPassengers", "Value=1", ENDITEM,
			"Name=advanceDiscount", "Value=0", ENDITEM,
			"Name=seatType", "Value={seatType}", ENDITEM,
			"Name=seatPref", "Value={seatPref}", ENDITEM,
			"Name=reserveFlights.x", "Value=54", ENDITEM,
			"Name=reserveFlights.y", "Value=1", ENDITEM,
			LAST);
	
		
	
	lr_end_transaction("choose_ticket", LR_AUTO);

    lr_think_time(5);
    
	lr_start_transaction("payment_form");
	
		web_reg_find("Text/IC=Customer Name",                                                                          //FIND******************
			LAST);
		
		web_revert_auto_header("Origin");
	
		web_revert_auto_header("Sec-Fetch-User");
	
		web_revert_auto_header("Upgrade-Insecure-Requests");
	
		web_add_header("Origin", 
			"http://localhost:1080");
	
		web_submit_data("reservations.pl_3",
			"Action=http://localhost:1080/cgi-bin/reservations.pl",
			"Method=POST",
			"TargetFrame=",
			"RecContentType=text/html",
			"Referer=http://localhost:1080/cgi-bin/reservations.pl",
			"Snapshot=t35.inf",
			"Mode=HTML",
			ITEMDATA,
			"Name=firstName", "Value={firstName}", ENDITEM,
			"Name=lastName", "Value={lastName}", ENDITEM,
			"Name=address1", "Value={address1}", ENDITEM,
			"Name=address2", "Value={address2}", ENDITEM,
			"Name=pass1", "Value={firstName} {lastName}", ENDITEM,
			"Name=creditCard", "Value={cardNum}", ENDITEM,
			"Name=expDate", "Value={cardExpDate}", ENDITEM,
			"Name=oldCCOption", "Value=on", ENDITEM,
			"Name=numPassengers", "Value=1", ENDITEM,
			"Name=seatType", "Value={seatType}", ENDITEM,
			"Name=seatPref", "Value={seatPref}", ENDITEM,
			"Name=outboundFlight", "Value={outboundFlight}", ENDITEM,
			"Name=advanceDiscount", "Value=0", ENDITEM,
			"Name=returnFlight", "Value={returnFlight}", ENDITEM,
			"Name=JSFormSubmit", "Value=off", ENDITEM,
			"Name=buyFlights.x", "Value=51", ENDITEM,
			"Name=buyFlights.y", "Value=13", ENDITEM,
			"Name=.cgifields", "Value=saveCC", ENDITEM,
			LAST);
		
	lr_end_transaction("payment_form", LR_AUTO);
	
	lr_think_time(5);
	
	logout();
	
	lr_end_transaction("UC3_BuyTicket", LR_AUTO);

	return 0;
}
