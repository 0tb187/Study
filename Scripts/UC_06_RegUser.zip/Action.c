Action()
{
	lr_start_transaction("UC_06_RegUser");

	
	lr_start_transaction("open_home_page");
	
		web_add_auto_header("Sec-Fetch-Site", 
			"none");
	
		web_add_auto_header("Sec-Fetch-Dest", 
			"document");
	
		web_add_auto_header("Sec-Fetch-Mode", 
			"navigate");
	
		web_add_auto_header("Sec-Fetch-User", 
			"?1");
	
		web_add_auto_header("Upgrade-Insecure-Requests", 
			"1");
	
		web_add_auto_header("sec-ch-ua", 
			"\"Google Chrome\";v=\"111\", \"Not(A:Brand\";v=\"8\", \"Chromium\";v=\"111\"");
	
		web_add_auto_header("sec-ch-ua-mobile", 
			"?0");
	
		web_add_auto_header("sec-ch-ua-platform", 
			"\"Windows\"");
		
		web_reg_find("Text=Web Tours",                                                                          //FIND******************
			LAST);
	
		web_url("WebTours", 
			"URL=http://localhost:1080/WebTours/", 
			"TargetFrame=", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=", 
			"Snapshot=t30.inf", 
			"Mode=HTML", 
			LAST);
		
	lr_end_transaction("open_home_page", LR_AUTO);
	
	lr_think_time(5);

		web_set_sockets_option("SSL_VERSION", "AUTO");
	
	lr_start_transaction("sign_up_page");
	
		web_add_auto_header("Sec-Fetch-Dest",
			"frame");
	
		web_revert_auto_header("Sec-Fetch-User");
	
		web_revert_auto_header("Upgrade-Insecure-Requests");
	
		web_add_auto_header("Sec-Fetch-Site", 
			"same-origin");
	
		web_reg_find("Text/IC=First time registering?",
		LAST);

		web_url("sign up now", 
			"URL=http://localhost:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
			"TargetFrame=body", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/WebTours/home.html", 
			"Snapshot=t2.inf", 
			"Mode=HTML", 
			LAST);
	
	lr_end_transaction("sign_up_page", LR_AUTO);

	lr_think_time(5);
	
	lr_start_transaction("reg_form");
	
		web_add_header("Origin", 
			"http://localhost:1080");
	
		web_add_auto_header("Sec-Fetch-User", 
			"?1");
	
		web_add_auto_header("Upgrade-Insecure-Requests", 
			"1");
		
		web_reg_find("Text/IC=We hope we can",
		LAST);

		web_submit_data("login.pl", 
			"Action=http://localhost:1080/cgi-bin/login.pl", 
			"Method=POST", 
			"TargetFrame=info", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
			"Snapshot=t3.inf", 
			"Mode=HTML", 
			ITEMDATA, 
			"Name=username", "Value={b}{a}{b}{b}{a}{b}{a}", ENDITEM, 
			"Name=password", "Value={randomPass}", ENDITEM, 
			"Name=passwordConfirm", "Value={randomPass}", ENDITEM, 
			"Name=f" 
			"irstName", "Value={bigB}{a}{b}{a}{b}", ENDITEM,
			"Name=lastName", "Value={bigA}{b}{a}{b}", ENDITEM, 
			"Name=address1", "Value={address1}", ENDITEM, 
			"Name=address2", "Value={address2}", ENDITEM, 
			"Name=register.x", "Value=38", ENDITEM, 
			"Name=register.y", "Value=11", ENDITEM, 
			LAST);
		
	lr_end_transaction("reg_form", LR_AUTO);

	lr_think_time(5);
	
	lr_start_transaction("signed_up_new_user_home_page");

	
		web_revert_auto_header("Sec-Fetch-User");
	
		web_revert_auto_header("Upgrade-Insecure-Requests");
		
		web_reg_find("Text/IC=already logged on",
		LAST);

		web_url("button_next.gif", 
			"URL=http://localhost:1080/cgi-bin/welcome.pl?page=menus", 
			"TargetFrame=body", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/cgi-bin/login.pl", 
			"Snapshot=t4.inf", 
			"Mode=HTML", 
			LAST);

	lr_end_transaction("signed_up_new_user_home_page", LR_AUTO);
	
	lr_think_time(5);

	logout();

	lr_end_transaction("UC_06_RegUser", LR_AUTO);

	return 0;
}