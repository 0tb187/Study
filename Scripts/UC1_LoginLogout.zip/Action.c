Action()
{

	lr_start_transaction("UC1_LoginLogout");
	
	login();

	logout();

	lr_end_transaction("UC1_LoginLogout", LR_AUTO);

	return 0;
}