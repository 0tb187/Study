Action()
{
	lr_start_transaction("UC_02_FindTicket");
	
	login();
	
	lr_start_transaction("search_flights");

		web_add_auto_header("Sec-Fetch-User", 
			"?1");
	
		web_add_auto_header("Upgrade-Insecure-Requests", 
			"1");
	
		web_reg_find("Text/IC=User has returned",
			LAST);
	
		web_url("Search Flights Button", 
			"URL=http://localhost:1080/cgi-bin/welcome.pl?page=search", 
			"TargetFrame=body", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
			"Snapshot=t3.inf", 
			"Mode=HTML", 
			LAST);
	
	lr_end_transaction("search_flights", LR_AUTO);
	
	lr_think_time(5);
	
	lr_start_transaction("choose_flight_parameters");

	/*Correlation comment - Do not change!  Original value='011;498;04/12/2023' Name ='outboundFlight' Type ='Manual'*/
		web_reg_save_param_attrib(
			"ParamName=outboundFlight",
			"TagName=input",
			"Extract=value",
			"Name=outboundFlight",
			"Type=radio",
			SEARCH_FILTERS,
			"IgnoreRedirections=No",
			LAST);
	
		web_add_header("Origin", 
			"http://localhost:1080");
	
		web_reg_find("Text/IC=from <b>{departCity}</b> to <b>{arriveCity}</b>",                                                 //FIND******************
			LAST);
	
	
		web_submit_data("reservations.pl", 
			"Action=http://localhost:1080/cgi-bin/reservations.pl", 
			"Method=POST", 
			"TargetFrame=", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/cgi-bin/reservations.pl?page=welcome", 
			"Snapshot=t4.inf", 
			"Mode=HTML", 
			ITEMDATA, 
			"Name=advanceDiscount", "Value=0", ENDITEM, 
			"Name=depart", "Value={departCity}", ENDITEM, 
			"Name=departDate", "Value={departDate}", ENDITEM, 
			"Name=arrive", "Value={arriveCity}", ENDITEM, 
			"Name=returnDate", "Value={returnDate}", ENDITEM, 
			"Name=numPassengers", "Value=1", ENDITEM, 
			"Name=seatPref", "Value={seatPref}", ENDITEM, 
			"Name=seatType", "Value={seatType}", ENDITEM, 
			"Name=findFlights.x", "Value=45", ENDITEM, 
			"Name=findFlights.y", "Value=7", ENDITEM, 
			"Name=.cgifields", "Value=roundtrip", ENDITEM, 
			"Name=.cgifields", "Value=seatType", ENDITEM, 
			"Name=.cgifields", "Value=seatPref", ENDITEM, 
			LAST);
	
	lr_end_transaction("choose_flight_parameters", LR_AUTO);
	
	lr_think_time(5);
	
	lr_start_transaction("choose_ticket");
	
	web_reg_find("Text={outboundFlight}",                                                                          //FIND******************
			LAST);

		web_submit_data("reservations.pl_2",
			"Action=http://localhost:1080/cgi-bin/reservations.pl",
			"Method=POST",
			"TargetFrame=",
			"RecContentType=text/html",
			"Referer=http://localhost:1080/cgi-bin/reservations.pl",
			"Snapshot=t5.inf",
			"Mode=HTML",
			ITEMDATA,
			"Name=outboundFlight", "Value={outboundFlight}", ENDITEM,
			"Name=numPassengers", "Value=1", ENDITEM,
			"Name=advanceDiscount", "Value=0", ENDITEM,
			"Name=seatType", "Value={seatType}", ENDITEM,
			"Name=seatPref", "Value={seatPref}", ENDITEM,
			"Name=reserveFlights.x", "Value=38", ENDITEM,
			"Name=reserveFlights.y", "Value=6", ENDITEM,
			LAST);
	
	lr_end_transaction("choose_ticket", LR_AUTO);

    lr_think_time(5);
	
	logout();
	
	lr_end_transaction("UC_02_FindTicket", LR_AUTO);

	
	return 0;
}