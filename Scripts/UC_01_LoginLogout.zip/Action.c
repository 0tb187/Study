Action()
{

	lr_start_transaction("UC_01_LoginLogout");
	
	login();

	logout();

	lr_end_transaction("UC_01_LoginLogout", LR_AUTO);

	return 0;
}