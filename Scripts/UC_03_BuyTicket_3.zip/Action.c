Action()
{
	lr_start_transaction("UC_03_Buyticket_3");

	login();
	
	lr_start_transaction("search_flights");
		
	web_reg_find("Text=User has returned",                                                                          //FIND******************
			LAST);

		web_add_auto_header("Sec-Fetch-Mode", 
			"navigate");
	
		web_add_auto_header("Sec-Fetch-Dest", 
			"frame");
	
		web_add_auto_header("Sec-Fetch-Site", 
			"same-origin");
	
		web_add_auto_header("Sec-Fetch-User", 
			"?1");
	
		web_add_auto_header("Upgrade-Insecure-Requests", 
			"1");
	
		web_add_auto_header("sec-ch-ua", 
			"\"Google Chrome\";v=\"111\", \"Not(A:Brand\";v=\"8\", \"Chromium\";v=\"111\"");
	
		web_add_auto_header("sec-ch-ua-mobile", 
			"?0");
	
		web_add_auto_header("sec-ch-ua-platform", 
			"\"Windows\"");
	
		web_url("welcome.pl", 
			"URL=http://localhost:1080/cgi-bin/welcome.pl?page=search", 
			"TargetFrame=", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
			"Snapshot=t3.inf", 
			"Mode=HTML", 
			LAST);
		
	lr_end_transaction("search_flights", LR_AUTO);
	
	lr_think_time(5);
	
	lr_start_transaction("choose_flight_parameters");
	
	web_reg_find("Text={departCity}",                                                                          //FIND******************
			LAST);
	
		web_add_auto_header("Origin", 
			"http://localhost:1080");
	
	
	/*Correlation comment - Do not change!  Original value='011;498;04/12/2023' Name ='outboundFlight' Type ='Manual'*/
		web_reg_save_param_attrib(
			"ParamName=outboundFlightsArr",
			"TagName=input",
			"Extract=value",
			"Name=outboundFlight",
			"Ordinal=ALL",
			"Type=radio",
			SEARCH_FILTERS,
			"IgnoreRedirections=No",
			LAST);
	
	/*Correlation comment - Do not change!  Original value='101;498;04/09/2023' Name ='returnFlight' Type ='Manual'*/
		web_reg_save_param_attrib(
			"ParamName=returnFlightsArr",
			"TagName=input",
			"Extract=value",
			"Name=returnFlight",
			"Ordinal=ALL",
			"Type=radio",
			SEARCH_FILTERS,
			"IgnoreRedirections=No",
			LAST);
	
		web_submit_data("reservations.pl", 
			"Action=http://localhost:1080/cgi-bin/reservations.pl", 
			"Method=POST", 
			"TargetFrame=", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/cgi-bin/reservations.pl?page=welcome", 
			"Snapshot=t4.inf", 
			"Mode=HTML", 
			ITEMDATA, 
			"Name=advanceDiscount", "Value=0", ENDITEM, 
			"Name=depart", "Value={departCity}", ENDITEM, 
			"Name=departDate", "Value={departDate}", ENDITEM, 
			"Name=arrive", "Value={arriveCity}", ENDITEM, 
			"Name=returnDate", "Value={returnDate}", ENDITEM, 
			"Name=numPassengers", "Value={randomNum}", ENDITEM,
			"Name=roundtrip", "Value=on", ENDITEM,			
			"Name=seatPref", "Value={seatPref}", ENDITEM, 
			"Name=seatType", "Value={seatType}", ENDITEM, 
			"Name=findFlights.x", "Value=47", ENDITEM, 
			"Name=findFlights.y", "Value=4", ENDITEM, 
			"Name=.cgifields", "Value=roundtrip", ENDITEM, 
			"Name=.cgifields", "Value=seatType", ENDITEM, 
			"Name=.cgifields", "Value=seatPref", ENDITEM, 
			LAST);

	lr_end_transaction("choose_flight_parameters", LR_AUTO);
	
	lr_think_time(5);
	
	lr_start_transaction("choose_ticket");
	
	lr_save_string(lr_paramarr_random("outboundFlightsArr"),"outboundFlight");
	lr_save_string(lr_paramarr_random("returnFlightsArr"),"returnFlight");
	
	web_reg_find("Text={outboundFlight}",                                                                          //FIND******************
			LAST);

		web_submit_data("reservations.pl_2",
			"Action=http://localhost:1080/cgi-bin/reservations.pl",
			"Method=POST",
			"TargetFrame=",
			"RecContentType=text/html",
			"Referer=http://localhost:1080/cgi-bin/reservations.pl",
			"Snapshot=t5.inf",
			"Mode=HTML",
			ITEMDATA,
			"Name=outboundFlight", "Value={outboundFlight}", ENDITEM,
			"Name=returnFlight", "Value={returnFlight}", ENDITEM,
			"Name=numPassengers", "Value={randomNum}", ENDITEM,
			"Name=advanceDiscount", "Value=0", ENDITEM,
			"Name=seatType", "Value={seatType}", ENDITEM,
			"Name=seatPref", "Value={seatPref}", ENDITEM,
			"Name=reserveFlights.x", "Value=38", ENDITEM,
			"Name=reserveFlights.y", "Value=6", ENDITEM,
			LAST);
	
	lr_end_transaction("choose_ticket", LR_AUTO);

    lr_think_time(5);
	
	lr_start_transaction("payment_form");
	
		web_revert_auto_header("Origin");
	
		web_revert_auto_header("Sec-Fetch-User");
	
		web_revert_auto_header("Upgrade-Insecure-Requests");
	
		web_add_header("Origin", 
			"http://localhost:1080");
		
	web_reg_find("Text/IC=from {departCity} to {arriveCity}",                                                 //FIND******************
			LAST);
	
		web_submit_data("reservations.pl_3",
			"Action=http://localhost:1080/cgi-bin/reservations.pl",
			"Method=POST",
			"TargetFrame=",
			"RecContentType=text/html",
			"Referer=http://localhost:1080/cgi-bin/reservations.pl",
			"Snapshot=t6.inf",
			"Mode=HTML",
			ITEMDATA,
			"Name=firstName", "Value={firstName}", ENDITEM,
			"Name=lastName", "Value={lastName}", ENDITEM,
			"Name=address1", "Value={address1}", ENDITEM,
			"Name=address2", "Value={address2}", ENDITEM,
			"Name=pass1", "Value={addPassFirstName} {addPassLastName}", ENDITEM,
			"Name=pass2", "Value={addPassFirstName} {addPassLastName}", ENDITEM,
			"Name=pass3", "Value={addPassFirstName} {addPassLastName}", ENDITEM,
			"Name=pass4", "Value={addPassFirstName} {addPassLastName}", ENDITEM,
			"Name=pass5", "Value={addPassFirstName} {addPassLastName}", ENDITEM,
			"Name=pass6", "Value={addPassFirstName} {addPassLastName}", ENDITEM,
			"Name=pass7", "Value={addPassFirstName} {addPassLastName}", ENDITEM,
			"Name=pass8", "Value={addPassFirstName} {addPassLastName}", ENDITEM,
			"Name=pass9", "Value={addPassFirstName} {addPassLastName}", ENDITEM,
			"Name=pass10", "Value={addPassFirstName} {addPassLastName}", ENDITEM,
			"Name=creditCard", "Value={cardNum}", ENDITEM,
			"Name=expDate", "Value={cardExpDate}", ENDITEM,
			"Name=oldCCOption", "Value=", ENDITEM,
			"Name=numPassengers", "Value={randomNum}", ENDITEM,
			"Name=seatType", "Value={seatType}", ENDITEM,
			"Name=seatPref", "Value={seatPref}", ENDITEM,
			"Name=outboundFlight", "Value={outboundFlight}", ENDITEM,
			"Name=advanceDiscount", "Value=0", ENDITEM,
			"Name=returnFlight", "Value={returnFlight}", ENDITEM,
			"Name=JSFormSubmit", "Value=off", ENDITEM,
			"Name=buyFlights.x", "Value=43", ENDITEM,
			"Name=buyFlights.y", "Value=14", ENDITEM,
			"Name=.cgifields", "Value=saveCC", ENDITEM,
			LAST);
	
	lr_end_transaction("payment_form", LR_AUTO);
	
	lr_think_time(5);
	
	lr_start_transaction("itinerary_page");
		
		web_reg_find("Text=User wants",                                                                          //FIND******************
			LAST);
			
		web_add_auto_header("Sec-Fetch-User", 
			"?1");
	
		web_add_auto_header("Upgrade-Insecure-Requests", 
			"1");
	
		web_url("Itinerary Button", 
			"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
			"TargetFrame=body", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
			"Snapshot=t3.inf", 
			"Mode=HTML", 
			LAST);
		
	lr_end_transaction("itinerary_page", LR_AUTO);
	
	lr_end_transaction("UC_03_Buyticket_3", LR_AUTO);


	return 0;
}