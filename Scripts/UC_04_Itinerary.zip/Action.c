Action()
{
	lr_start_transaction("UC_04_Itinerary");

	login();
	
	lr_start_transaction("itinerary_page");
	
		web_reg_find("Text=User wants",                                                                          //FIND******************
			LAST);
	
		web_add_auto_header("Sec-Fetch-User", 
			"?1");
	
		web_add_auto_header("Upgrade-Insecure-Requests", 
			"1");
	
		web_url("Itinerary Button", 
			"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
			"TargetFrame=body", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=flights", 
			"Snapshot=t36.inf", 
			"Mode=HTML", 
			LAST);
	
	lr_end_transaction("itinerary_page", LR_AUTO);
	
	lr_think_time(5);
	
	logout();
	
	lr_end_transaction("UC_04_Itinerary", LR_AUTO);

	
	return 0;
}
