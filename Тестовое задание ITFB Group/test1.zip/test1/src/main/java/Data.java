

public class Data {
    public static String username = "Bob";
    public static String email = "bob@gmail.com";
    public static String address1 = "Saint-Petersburg, Nevsky 3";
    public static String address2 = "Moskow, Chertanovskaya 13";
}
